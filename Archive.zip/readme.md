# Defly Power Up+
## Ideas:
  * Have themes (using CSS)
  * Change bg on gamemode change
  * Add sharing feature for custom skins
  * Export skin/level presets as a file
