window.open('https://defly.io/');
window.close();
